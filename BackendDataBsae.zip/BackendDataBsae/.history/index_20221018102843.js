const express=require('express');
const app=express();



app.listen(1000,()=>{
    console.log("Node Served Started");
})